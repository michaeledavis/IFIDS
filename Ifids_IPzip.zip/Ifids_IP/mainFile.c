#include <stdio.h>
#include <stdlib.h>
#include "Ifids_IP.h"
int main( int argc, const char* argv[] )
{
	char* rangeSetter = "192-194.168-190.1-255.1-255";
	char* ipTester = "193.170.3.3";
	ifids_ip* ifidsResult = (ifids_ip*)malloc(sizeof(ifids_ip));
	ifidsResult = parseIP(rangeSetter);
	int result = ipIsInRange(ipTester, ifidsResult);
	printf("%d",result);
}
